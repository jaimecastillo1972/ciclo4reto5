/**
 * La URL base del backend.
 * Local = "http://localhost:8080/api/"
 * Remote = "http://129.151.121.121:8080/api/"
 */
var service = "http://localhost:8080/api/"


var serviceU = service + "user/";

var serviceP = service + "hairproducts/";

var serviceO = service + "order/"