var dato;

function validarExistencia(valor) {

    return $.ajax({
        url: "http://localhost:8080/api/user/" + valor,
        method: "GET",
        async: false
    }).responseJSON;
}

$("#login").click(function() {

    switch (true) {

        case ($("#email").val() == "" || $.trim($("#contrasena").val()) == ""):

            alert("Por favor ingrese el correo y/o la contraseña");
            break;

        case validarEmail($("#email").val()) == false:

            alert("La dirección de email es incorrecta.");
            break;

        case validarExistencia($("#email").val()) == false:

            alert("No existe un usuario asociado al correo");
            break;

        default:

            let data = {
                email: $("#email").val(),
                password: $("#contrasena").val(),
            };
            $.ajax({
                url: "http://localhost:8080/api/user/" + data.email + "/" + data.password,
                method: "GET",
                dataType: "json",
                success: function(response) {

                    if (response.name == "NO DEFINIDO")
                        alert("Contraseña incorrecta")

                    else
                        alert("Bienvenido " + response.name)

                }
            });

    }
});

$("#registrar").click(function() {

    switch (true) {

        case $("#emailRegistro").val() == "" ||
        $.trim($("#contrasenaRegistro").val()) == "" ||
        $.trim($("#userRegistro").val()) == "" ||
        $.trim($("#contrasenaRegistro2").val()) == "":

            alert("Por favor complete todos los campos");
            break;

        case validarEmail($("#emailRegistro").val()) == false:

            alert("La dirección de email es incorrecta.");
            break;

        case $("#contrasenaRegistro").val() != $("#contrasenaRegistro2").val():

            alert("Las contraseñas no coinciden");
            break;

        case validarExistencia($("#emailRegistro").val()):

            alert("Ya existe un usuario asociado al correo");
            break;

        default:

            let datos = {
                email: $("#emailRegistro").val(),
                password: $("#contrasenaRegistro").val(),
                name: $("#userRegistro").val(),
            };
            $.ajax({
                url: "http://localhost:8080/api/user/new",
                method: "POST",
                dataType: "json",
                data: JSON.stringify(datos),
                contentType: "application/json",
                Headers: {
                    "Content-Type": "application/json",
                },
                statusCode: {
                    201: function(response) {
                        console.log(response);
                    },
                    400: function(response) {
                        console.log("Bad Request");
                    },
                },

            });

            $('#btnCerrar').click();

    }

});

$("#contrasenaRegistro2").change(function() {
    if ($("#contrasenaRegistro").val() != $("#contrasenaRegistro2").val()) {
        $("#contrasenaRegistro2").css("border-color", "red");
        $("#contrasenaRegistro").css("border-color", "red");
    } else {
        $("#contrasenaRegistro2").css("border-color", "");
        $("#contrasenaRegistro").css("border-color", "");
    }
});

function validarEmail(valor) {
    expr = /^(?:[^<>()[\].,;:\s@"]+(\.[^<>()[\].,;:\s@"]+)*|"[^\n"]+")@(?:[^<>()[\].,;:\s@"]+\.)+[^<>()[\]\.,;:\s@"]{2,63}$/i;
    return expr.test(valor);
}